n = f_hacer_matriz_mandelbrot(2000);
imagesc(n);